var namespaces_dup =
[
    [ "fftw", "namespacefftw.html", null ]
];