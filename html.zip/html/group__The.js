var group__The =
[
    [ "dobutton", "group__The.html#ga312bd11f1f9d9f12522200f7855ffc4b", null ],
    [ "exitbutton", "group__The.html#ga4b56ee097c62ed62fd7bf2bd75c269df", null ],
    [ "fabutton", "group__The.html#ga73fce5053e82b9038dcabb1ad05aadb5", null ],
    [ "feedbackbutton", "group__The.html#gae371402c54deee260faf8104d9567d92", null ],
    [ "labutton", "group__The.html#gab3dc8a2afb89aade606591133cadca38", null ],
    [ "learningbutton", "group__The.html#ga7839e6229f6372185008000ab1d6b290", null ],
    [ "melody", "group__The.html#ga8fedbafc727b1f340f81f6d4c27c6623", null ],
    [ "mibutton", "group__The.html#ga59f95aa4c501bab34a9a4ee65d20f635", null ],
    [ "piano", "group__The.html#ga370a0e37d626044e7848603309c0f61f", null ],
    [ "quitbutton", "group__The.html#ga3f4d8d0fdddafb0bee3ca61070f52f59", null ],
    [ "rebutton", "group__The.html#ga2749813d9abc6631ecaaac2738e1300b", null ],
    [ "recognizingbutton", "group__The.html#gaa0318e2b6ca5ea773d456cf3f43c4e23", null ],
    [ "resumebutton", "group__The.html#ga8321a005f57cf52cb2b20182a314510b", null ],
    [ "sobutton", "group__The.html#ga1a433a6fc45539c4d743e9f7f9839f36", null ],
    [ "stopbutton", "group__The.html#ga5f9811ebf5de9ad1df5b2e65ac5cefe6", null ],
    [ "stoprecording", "group__The.html#gafd5978c8ad86c12fac7d30bada130f4e", null ],
    [ "testingbutton", "group__The.html#gaf08a56611d655b0e3464644332ab2c79", null ],
    [ "text", "group__The.html#gaab394c1812db309d61d3188ebd7898bb", null ],
    [ "text3", "group__The.html#ga5bdf984ca9f81bff7b69479e6361b7fa", null ],
    [ "tibutton", "group__The.html#ga81cdb48fbb9806fd7f7dcfddb6069d9e", null ]
];