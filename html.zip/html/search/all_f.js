var searchData=
[
  ['samplerate_79',['sampleRate',['../group__Other.html#gaabb5287a7bdfda6bc9c5514f2914ea72',1,'Window']]],
  ['sdft_80',['sdft',['../fft_8h.html#a10e0050543e81b22548d59c5083890c4',1,'fft.h']]],
  ['sobutton_81',['sobutton',['../group__The.html#ga1a433a6fc45539c4d743e9f7f9839f36',1,'Window']]],
  ['sopressedslot_82',['SoPressedSlot',['../group__Note.html#gacbb35b80ce11478a5fac25dd43b900a2',1,'Window']]],
  ['stopbutton_83',['stopbutton',['../group__The.html#ga5f9811ebf5de9ad1df5b2e65ac5cefe6',1,'Window']]],
  ['stoprecording_84',['stopRecording',['../classWindow.html#a1e1b19159554e5d206cf23418449075e',1,'Window']]],
  ['stoprecording_85',['stoprecording',['../group__The.html#gafd5978c8ad86c12fac7d30bada130f4e',1,'Window']]]
];
