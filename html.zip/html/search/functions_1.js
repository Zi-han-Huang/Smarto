var searchData=
[
  ['clearnotes_108',['clearnotes',['../classWindow.html#ae467f32b4718e20cdd4ffe31c27afb38',1,'Window']]]
];
