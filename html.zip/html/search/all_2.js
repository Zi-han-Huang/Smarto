var searchData=
[
  ['c_7',['c',['../group__Other.html#ga38ede5a678cb2e1e8e183b96d6bdb40c',1,'Window']]],
  ['clearnotes_8',['clearnotes',['../classWindow.html#ae467f32b4718e20cdd4ffe31c27afb38',1,'Window']]],
  ['clickable_20buttons_20in_20both_20main_20qt_20window_20and_20sub_20window_2e_9',['Clickable buttons in both main QT window and sub window.',['../group__The.html',1,'']]],
  ['coeffs_10',['coeffs',['../fft_8h.html#aac294c1d0d23893ebbcb31342baa3d3a',1,'fft.h']]],
  ['complex_11',['complex',['../fft_8h.html#a1c1b16cc02d518bbe753449171ab7033',1,'fft.h']]]
];
