var searchData=
[
  ['dopressedslot_109',['DoPressedSlot',['../group__Note.html#ga5b525a7fff958649f5b1acaa4970f938',1,'Window']]]
];
