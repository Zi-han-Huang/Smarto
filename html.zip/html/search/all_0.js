var searchData=
[
  ['a_0',['a',['../group__Other.html#ga5313fdd39e4f018a85d46d304a9e3f6c',1,'Window']]],
  ['add_data_1',['add_data',['../fft_8h.html#ac7d7114419f45bd170212b59a8abd8e2',1,'fft.h']]],
  ['audio_2',['audio',['../group__Other.html#ga67f748df8d5f7525b5f76886820a1646',1,'Window']]],
  ['audiorecorderslot_3',['audioRecorderSlot',['../classWindow.html#a5ce395366f9041b577b4c9271289044d',1,'Window']]]
];
