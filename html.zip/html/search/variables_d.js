var searchData=
[
  ['quitbutton_176',['quitbutton',['../group__The.html#ga3f4d8d0fdddafb0bee3ca61070f52f59',1,'Window']]]
];
