var searchData=
[
  ['b_140',['b',['../group__Other.html#ga980f06ae68d510f349795eee099fd9b5',1,'Window']]],
  ['buffertime_141',['bufferTime',['../group__Other.html#ga641304018c42dc8450f206a2fb4c3b37',1,'Window']]]
];
