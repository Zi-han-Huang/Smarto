var searchData=
[
  ['objects_2c_20variables_20and_20some_20constant_20vaviables_20which_20invisible_53',['objects, variables and some constant vaviables which invisible',['../group__Other.html',1,'']]],
  ['oldest_data_54',['oldest_data',['../fft_8h.html#a81294f27d0706db63271f6d462dc00f4',1,'fft.h']]],
  ['out1_55',['out1',['../fft_8h.html#af178687a82260e3acf2d49d7298fd4d2',1,'fft.h']]],
  ['out2_56',['out2',['../fft_8h.html#a6fc5f76b216a7447a4795e213bcf1812',1,'fft.h']]]
];
