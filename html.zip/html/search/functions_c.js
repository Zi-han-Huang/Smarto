var searchData=
[
  ['sdft_131',['sdft',['../fft_8h.html#a10e0050543e81b22548d59c5083890c4',1,'fft.h']]],
  ['sopressedslot_132',['SoPressedSlot',['../group__Note.html#gacbb35b80ce11478a5fac25dd43b900a2',1,'Window']]],
  ['stoprecording_133',['stopRecording',['../classWindow.html#a1e1b19159554e5d206cf23418449075e',1,'Window']]]
];
