var searchData=
[
  ['b_4',['b',['../group__Other.html#ga980f06ae68d510f349795eee099fd9b5',1,'Window']]],
  ['buffertime_5',['bufferTime',['../group__Other.html#ga641304018c42dc8450f206a2fb4c3b37',1,'Window']]],
  ['buttons_20press_20signal_20group_2e_6',['buttons press signal group.',['../group__Note.html',1,'']]]
];
