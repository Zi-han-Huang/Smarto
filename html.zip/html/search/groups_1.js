var searchData=
[
  ['clickable_20buttons_20in_20both_20main_20qt_20window_20and_20sub_20window_2e_197',['Clickable buttons in both main QT window and sub window.',['../group__The.html',1,'']]]
];
