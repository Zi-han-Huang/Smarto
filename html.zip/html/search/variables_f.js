var searchData=
[
  ['samplerate_182',['sampleRate',['../group__Other.html#gaabb5287a7bdfda6bc9c5514f2914ea72',1,'Window']]],
  ['sobutton_183',['sobutton',['../group__The.html#ga1a433a6fc45539c4d743e9f7f9839f36',1,'Window']]],
  ['stopbutton_184',['stopbutton',['../group__The.html#ga5f9811ebf5de9ad1df5b2e65ac5cefe6',1,'Window']]],
  ['stoprecording_185',['stoprecording',['../group__The.html#gafd5978c8ad86c12fac7d30bada130f4e',1,'Window']]]
];
