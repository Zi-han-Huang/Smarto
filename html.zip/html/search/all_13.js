var searchData=
[
  ['_7ewindow_98',['~Window',['../classWindow.html#a245d821e6016fa1f6970ccbbedd635f6',1,'Window']]]
];
