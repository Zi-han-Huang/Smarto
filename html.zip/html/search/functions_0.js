var searchData=
[
  ['add_data_106',['add_data',['../fft_8h.html#ac7d7114419f45bd170212b59a8abd8e2',1,'fft.h']]],
  ['audiorecorderslot_107',['audioRecorderSlot',['../classWindow.html#a5ce395366f9041b577b4c9271289044d',1,'Window']]]
];
