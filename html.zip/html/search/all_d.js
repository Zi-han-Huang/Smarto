var searchData=
[
  ['quitapp_68',['quitApp',['../classWindow.html#a35f517c5891c4942e225cc3114ba9a43',1,'Window']]],
  ['quitbutton_69',['quitbutton',['../group__The.html#ga3f4d8d0fdddafb0bee3ca61070f52f59',1,'Window']]],
  ['qwidget_70',['QWidget',['../classQWidget.html',1,'']]]
];
