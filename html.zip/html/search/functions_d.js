var searchData=
[
  ['testingslot_134',['TestingSlot',['../classWindow.html#a09bbcccbe17f921d3cfa53c082c08814',1,'Window']]],
  ['tipressedslot_135',['TiPressedSlot',['../group__Note.html#ga6688656d500b510e9432507b151e54ee',1,'Window']]]
];
