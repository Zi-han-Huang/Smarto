var searchData=
[
  ['readmic_177',['readMic',['../group__Other.html#ga28ee98846d4e2350994a9300d157a785',1,'Window']]],
  ['readmicarray_178',['readmicarray',['../group__Other.html#ga9ef789ef7f15c8d1adabdf6c0fc82112',1,'Window']]],
  ['rebutton_179',['rebutton',['../group__The.html#ga2749813d9abc6631ecaaac2738e1300b',1,'Window']]],
  ['recognizingbutton_180',['recognizingbutton',['../group__The.html#gaa0318e2b6ca5ea773d456cf3f43c4e23',1,'Window']]],
  ['resumebutton_181',['resumebutton',['../group__The.html#ga8321a005f57cf52cb2b20182a314510b',1,'Window']]]
];
