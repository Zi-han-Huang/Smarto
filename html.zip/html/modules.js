var modules =
[
    [ "buttons press signal group.", "group__Note.html", "group__Note" ],
    [ "Clickable buttons in both main QT window and sub window.", "group__The.html", "group__The" ],
    [ "objects, variables and some constant vaviables which invisible", "group__Other.html", "group__Other" ]
];