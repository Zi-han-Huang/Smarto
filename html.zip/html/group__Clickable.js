var group__Clickable =
[
    [ "audiostopbutton", "group__Clickable.html#gadd551c09487e44f64a1a153896b6334a", null ],
    [ "dobutton", "group__Clickable.html#ga312bd11f1f9d9f12522200f7855ffc4b", null ],
    [ "exitbutton", "group__Clickable.html#ga4b56ee097c62ed62fd7bf2bd75c269df", null ],
    [ "fabutton", "group__Clickable.html#ga73fce5053e82b9038dcabb1ad05aadb5", null ],
    [ "labutton", "group__Clickable.html#gab3dc8a2afb89aade606591133cadca38", null ],
    [ "mibutton", "group__Clickable.html#ga59f95aa4c501bab34a9a4ee65d20f635", null ],
    [ "pushbutton1", "group__Clickable.html#ga2849c64ecb72445c189a53c59d5f35ee", null ],
    [ "pushbutton2", "group__Clickable.html#gacf55d5027e288226229be0451396491c", null ],
    [ "pushbutton3", "group__Clickable.html#ga6bdd972f50eac0a7b6fb4aa940aa95d0", null ],
    [ "quitbutton", "group__Clickable.html#ga3f4d8d0fdddafb0bee3ca61070f52f59", null ],
    [ "rebutton", "group__Clickable.html#ga2749813d9abc6631ecaaac2738e1300b", null ],
    [ "resumebutton", "group__Clickable.html#ga8321a005f57cf52cb2b20182a314510b", null ],
    [ "sobutton", "group__Clickable.html#ga1a433a6fc45539c4d743e9f7f9839f36", null ],
    [ "stopbutton", "group__Clickable.html#ga5f9811ebf5de9ad1df5b2e65ac5cefe6", null ],
    [ "Tibutton", "group__Clickable.html#gac23bc275844b3afca19a263ce177a96d", null ]
];